<?php 
$bddserver = "localhost";
$bddport = "3306";
$bddname = "testapi";
$bddlogin = "user_testapi";
$bddpass = "pass_testapi";


