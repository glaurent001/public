<?php
session_start();

$titre = "Site de test API";
//Début de l'affichage (mise en tampon)
ob_start();
?>

<!-- Page Heading -->
<!-- Page Heading -->
<h1 class="h3 mb-2 text-white bg-gradient-info border-bottom-info">Déploiement du site de test</h1>
<p></p>

<!-- Basic Card Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Base de données</h6>
    </div>
    <div class="card-body">
        <p>Ce site fonctionne avec une base de données</p>
        <p>Il faut déployer la base de données <span class="m-0 font-weight-bold text-danger">testapi</span>
            sur le serveur MySQL de la même machine qui héberge le site web (fichier testapi.sql à la racine de ce site)</p>
        <p>Il faut ensuite créer un <span class="m-0 font-weight-bold text-danger">utilisateur MySQL</span></p>
        <ul>
            <li>Nom d'utilisateur MySQL : user_testapi</li>
            <li>Mot de passe MySQL : pass_testapi</li>
            <li>Droits d'accès : aucun privilège global + CRUD sur la base testapi</li>
        </ul>
        <p>La liaison PHP - MySQL se fait dans le fichier /bdd/bddconfig.php</p>
    </div>
</div>

<!-- Basic Card Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Utilisation de l'API pour enregister des données dans la base</h6>
    </div>
    <div class="card-body">
        <p>Les requêtes doivent être envoyées en <span class="m-0 font-weight-bold text-danger">méthode POST</span></p>
        <p>Les données doivent être envoyées au <span class="m-0 font-weight-bold text-danger">format RAW</span> 
        (comme pour Dweet.io) et sont souhaitées au <span class="m-0 font-weight-bold text-danger">format JSON</span></p>
        <p>Adresse de l'API pour enregistrer une données : 
        <span class="m-0 font-weight-bold text-danger">http://adresse_du_site/api/insert.php</span></p>
    </div>
</div>

<!-- Basic Card Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Utilisation de l'API pour lire la dernière donnée enregistrée</h6>
    </div>
    <div class="card-body">
        <p>Les requêtes doivent être envoyées en <span class="m-0 font-weight-bold text-danger">méthode GET</span></p>
        <p>Adresse de l'API pour lire la dernière donnée : 
        <span class="m-0 font-weight-bold text-danger">http://adresse_du_site/api/get-latest.php</span></p>
    </div>
</div>

<?php
$contenu = ob_get_clean();
require 'gabarit/template.php';
?>