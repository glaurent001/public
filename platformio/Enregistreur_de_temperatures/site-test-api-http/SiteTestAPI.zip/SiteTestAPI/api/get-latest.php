<?php

require '../bdd/bddconfig.php';


    try {
        $objBdd = new PDO(
            "mysql:host=$bddserver;port=$bddport;dbname=$bddname;charset=utf8",
            $bddlogin,
            $bddpass
        );
        $objBdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $StmtData = $objBdd->prepare("SELECT * FROM data ORDER BY datepub DESC LIMIT 0,1");
        $StmtData->execute();

        $rowdata = $StmtData->fetch();
        if ($rowdata != false){
           
            $arrayData = array(
                "id" => $rowdata['id'],
                "datepub" => $rowdata['datepub'],
                "ipsrc" => $rowdata['ipsrc'],
                "donnee" => $rowdata['donnee']
            );

            echo json_encode($arrayData);
        }else{
            echo json_encode(array());
            // header("HTTP/1.0 204 No Content");
        }
    } catch (Exception $prmE) {
        // die('Erreur ; ' . $prmE->getMessage());
        header("HTTP/1.0 500");
    }

