<?php

require '../bdd/bddconfig.php';

$methodehttp = $_SERVER['REQUEST_METHOD'];
//données envoyées en mode RAW (comme pour dweet.io)
$donnee = urldecode(file_get_contents('php://input'));

// securisation des variables
if ($methodehttp == "POST" && $donnee != "") {
    //$donnee = strval(htmlspecialchars($donnee, ENT_NOQUOTES));
    $donnee = strval($donnee);
    $ipsrc = $_SERVER['REMOTE_ADDR'];

    // insert dans la base
    // requete sql

    try {
        $objBdd = new PDO(
            "mysql:host=$bddserver;port=$bddport;dbname=$bddname;charset=utf8",
            $bddlogin,
            $bddpass
        );
        $objBdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        //insertion
        $Stmt = $objBdd->prepare("insert INTO data (donnee,ipsrc) VALUES (:donnee, :ipsrc)");
        $Stmt->bindParam(':donnee', $donnee, PDO::PARAM_STR);
        $Stmt->bindParam(':ipsrc', $ipsrc, PDO::PARAM_STR);
        $Stmt->execute();

        //valeur de retour
        $StmtData = $objBdd->prepare("SELECT * FROM data ORDER BY datepub DESC LIMIT 0,1");
        $StmtData->execute();

        $rowdata = $StmtData->fetch();
        if ($rowdata != false) {

            $arrayData = array(
                "id" => $rowdata['id'],
                "datepub" => $rowdata['datepub'],
                "ipsrc" => $rowdata['ipsrc'],
                "donnee" => $rowdata['donnee']
            );

            echo json_encode($arrayData);
            //header("HTTP/1.0 201 Created");
        } else {
            header("HTTP/1.0 404 No found");
        }
    } catch (Exception $prmE) {
        //die('Erreur ; ' . $prmE->getMessage());
        header("HTTP/1.0 500");
    }
} else {
    header("HTTP/1.0 400 Invalid Request");
}
