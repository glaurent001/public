<?php 
session_start();
$titre = "Login";
//Début de l'affichage (mise en tampon)
ob_start();
?>

<!-- Outer Row -->
<div class="row justify-content-center">

    <div class="p-6">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">

                    <div class="p-6">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Content de vous revoir !</h1>
                            </div>
                            <form class="user" method="POST" action="login_action.php">
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="login" placeholder="Saisissez votre login..." required>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" name="password" placeholder="Mot de passe" required>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox small">
                                        <input type="checkbox" class="custom-control-input" id="customCheck">
                                        <label class="custom-control-label" for="customCheck">Se rappeler de moi</label>
                                    </div>
                                </div>
                                <input type="submit" value="Se connecter" class="btn btn-primary btn-user btn-block">
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="#">Mot de passe perdu ?</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>
<?php
$contenu = ob_get_clean();
require 'gabarit/template.php';
?>