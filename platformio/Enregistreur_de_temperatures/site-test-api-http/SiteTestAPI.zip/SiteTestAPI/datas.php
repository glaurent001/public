<?php
session_start();
require 'bdd/bddconfig.php';

try {
    $objBdd = new PDO("mysql:host=$bddserver;port=$bddport;dbname=$bddname;charset=utf8", 
                        $bddlogin, $bddpass);
    $objBdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //liste des articles
    $listeDonnees = $objBdd->prepare("SELECT * FROM data 
                                        ORDER BY datepub DESC
                                        LIMIT 100");
    $listeDonnees->execute();
} catch (Exception $prmE) {
    die('Erreur : ' . $prmE->getMessage());
}


$titre = "Site de test API";
//Début de l'affichage (mise en tampon)
ob_start();
?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-white bg-gradient-info border-bottom-info">Données reçues</h1>
<p></p>

<!-- DataTales Example -->
<div class="card shadow mb-4">

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover display" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>date publication</th>
                        <th>ip source</th>
                        <th>donnee</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listeDonnees as $donnee) { ?>
                        <tr class="trclient" data-id="<?php echo $donnee['id']; ?>">
                            <td><?= $donnee['id'] ?></td>
                            <td><?= $donnee['datepub'] ?></td>
                            <td><?= $donnee['ipsrc'] ?></td>
                            <td><?= htmlspecialchars($donnee['donnee']) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
$contenu = ob_get_clean();
require 'gabarit/template.php';
?>